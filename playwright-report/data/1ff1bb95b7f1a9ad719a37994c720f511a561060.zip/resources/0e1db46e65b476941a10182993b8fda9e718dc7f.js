(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_react-hook-form_dist_index_esm_mjs_06an-fx._.js","static/chunks/node_modules_zod_v4_0~~_id.._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_04ix9b-._.js","static/chunks/src_0ncg1j7._.js"],
    source: "dynamic"
});
